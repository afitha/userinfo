
import json
from rest_framework.decorators import APIView
from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import pymongo
from pymongo import MongoClient
import bcrypt
import jwt
from django.conf import settings
from rest_framework.response import Response

secret_key =settings.SECRET_KEY

client = pymongo.MongoClient('mongodb+srv://ansarafitha:root@cluster0.vgtdfso.mongodb.net/test')
# Creating database and collection objects
mydb = client['username']
mycol = mydb['registeration']
mycol.create_index('email', unique=True)


# View function to load the upload form
def insert_details(request): 
    # Loading the template file
    return render(request,'index.html')
    
    
class takeprofile(APIView):
    # POST method to handle the file upload
    def post(self, request, format=None):
            # Creating a list of form data and the uploaded file
            data = request.POST
            email=data['email']
            password=data['password']
            # Hash the password before storing it
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            mylist={'name':data['name'],'email':email,'phone':data['phone'],'password':hashed_password}
            # Inserting the data into MongoDB
            x = mycol.insert_one(mylist)
            # Rendering the success page with a success message
            return render(request,'index.html') 


class reguserprofile(APIView):  
     # GET method to retrieve a profile by name 
    def get(self,request,name):
        if not name:
            return JsonResponse({"error": "Name parameter is missing."})
        # Find the profile in the database by name and exclude the ID field
        mydoc = mycol.find({"name": name}, {"_id": 0,"password":0,"token":0})
        result = []
        for x in mydoc:
            result.append(x)
        # Return the profile as a JSON response
        return JsonResponse(result, safe=False)
    
    # DELETE method to delete a profile by name  
    def delete(self,request,name):
        if not name:
            return JsonResponse({"error": "Name parameter is missing."})
        # Delete the profile in the database by name
        mydoc= mycol.delete_one({"name":name})
        mydic = mycol.find({},{"_id": 0,"password":0,"token":0})
        result = []
        for x in mydic:
            result.append(x)
        # Return all profiles as a JSON response
        return JsonResponse(result, safe=False)

        
        
def login_view(request):
    if request.method =='POST':
        email = request.POST['emailid']
        password = request.POST['password']
        # Query the user collection for the provided email
        user = mycol.find_one({'email': email})
        if user is not None:
            hashed_password = user['password']
            # Check if the provided password matches the hashed password in the database
            if bcrypt.checkpw(password.encode('utf-8'), hashed_password):
                # Authentication successful
                # Generate a token
                token = jwt.encode({'email': email},settings.SECRET_KEY, algorithm='HS256')
                # Store the token in the user document in MongoDB
                mycol.update_one({'email': email}, {'$set': {'token': token}})
                # Render the interface template with the email variable
                return render(request,'upload.html',{'email':email})
            # Render the index template with an error message
        return render(request, 'index.html',{'error':'Invalid email or password.'})
    

def upload_view(request):
    if request.method =='POST':
        # Get the email from the request
        email = request.POST['emailid']
         # Get the uploaded file from the request
        uploaded_file = request.FILES['json_file']
         # Load the JSON document from the uploaded file
        document = json.load(uploaded_file)
         # Create a dictionary with the email and the loaded document
        mylist={'email':email, 'resume': document}
        # Insert the document into the 'userdemo' collection in MongoDB
        x = mydb.userdemo.insert_one(mylist)
        # Return a success response
        return render(request,'message.html')
       

      
            







        
    